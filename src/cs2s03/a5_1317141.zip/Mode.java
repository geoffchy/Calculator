package cs2s03;

public enum Mode { INTEGER, FLOAT }


