package cs2s03;

class DblVal extends Value {
double val ;
}