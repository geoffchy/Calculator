package cs2s03;

class IntVal extends Value {
int val;
	
}