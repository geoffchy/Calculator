package cs2s03;

abstract class Value{
Mode m;
}
